package jp.ac.dendai.c.jtp.myapplication1;
import java.util.ArrayList;
import jp.ac.dendai.c.jtp.myapplication1.mono.Mono;
public class TamaList extends ArrayList<Mono> {
    public TamaList() {
        super();
    }
}