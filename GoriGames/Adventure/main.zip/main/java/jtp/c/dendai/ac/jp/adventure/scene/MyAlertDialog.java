package jtp.c.dendai.ac.jp.adventure.scene;

        import android.app.AlertDialog;
        import android.content.Context;

public class MyAlertDialog extends AlertDialog {

    public MyAlertDialog(Context context) {
        super(context);
    }

    public MyAlertDialog(Context context, int theme) {
        super(context, theme);
    }
}