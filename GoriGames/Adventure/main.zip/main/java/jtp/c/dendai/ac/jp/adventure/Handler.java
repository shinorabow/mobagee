package jtp.c.dendai.ac.jp.adventure;
import jtp.c.dendai.ac.jp.adventure.scene.Scene;
public interface Handler {
    void step(Scene s);
}