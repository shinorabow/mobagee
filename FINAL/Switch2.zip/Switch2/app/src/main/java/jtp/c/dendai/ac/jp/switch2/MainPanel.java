package jtp.c.dendai.ac.jp.switch2;

import android.view.SurfaceView;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.JPanel;

/*
 * Created on 2005/06/06
 *
 */

/**
 * @author mori
 *  
 */
public class MainPanel extends SurfaceView implements Runnable, KeyListener {
    // パネルサイズ
    public static final int WIDTH = 640;
    public static final int HEIGHT = 480;

    // マップ
    private Map map;

    // プレイヤー
    private Player player;
    private Player2 pl2;
    
    //入れ替え数
    
    Score sc = new Score();
    

    public static int cnum = 0; //1:pl1が上 2:pl2が上
    
    private int ire = 3;
    
    
    public static int pnum = 0;

    // アクションキー
    private ActionKey goLeftKey;
    private ActionKey goRightKey;
    private ActionKey jumpKey;
    private ActionKey kirikaeKey;
    // ゲームループ用スレッド
    private Thread gameLoop;

    public MainPanel() {
        // パネルの推奨サイズを設定、pack()するときに必要
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        // パネルがキー入力を受け付けるようにする
        setFocusable(true);

        // アクションキーを作成
        goLeftKey = new ActionKey();
        goRightKey = new ActionKey();
        
        kirikaeKey = new ActionKey(ActionKey.DETECT_INITIAL_PRESS_ONLY);
        
        // ジャンプだけはキーを押し続けても1回だけしかジャンプしないようにする
        jumpKey = new ActionKey(ActionKey.DETECT_INITIAL_PRESS_ONLY);

        // マップを作成
        map = new Map("map01.dat");

        // プレイヤーを作成
 //       player = new Player(192, 32, "player.gif", map);
 player = new Player(128, 32, "player.gif", map);
        pl2 = new Player2(32, 32, "girl.gif", map);
        // キーイベントリスナーを登録
        addKeyListener(this);

        // ゲームループ開始
        gameLoop = new Thread(this);
        gameLoop.start();
    }

    /**
     * ゲームオーバー
     */
    public void gameOver() {
        // マップを作成
        map = new Map("map01.dat");

        // プレイヤーを作成
        player = new Player(128, 32, "player.gif", map);
        pl2 = new Player2(64, 32, "girl.gif", map);
    }
    
    
       public boolean iscol2() {
        Rectangle prect2 = new Rectangle((int)pl2.getX(), (int)pl2.getY(), pl2.getWidth(), pl2.getHeight());
        Rectangle prect1 = new Rectangle((int)player.getX(), (int)player.getY(), player.getWidth(), player.getHeight());
        // 自分の矩形と相手の矩形が重なっているか調べる
        if (prect2.intersects(prect1)) {
            return true;
        }
        
        return false;
    }
    
    

    /**
     * ゲームループ
     */
    public void run() {
        
        
        sc.setIre(10);
        
        while (true) {
            if (goLeftKey.isPressed()) {
                                switch(pnum){
                    case 0:
                           if(cnum ==2){
                            player.accelerateLeft();
                            pl2.accelerateLeft();
                            break;
                        }
                           else{
                        player.accelerateLeft();
                        break;}
                    case 1:
                        if(cnum ==1){
                            player.accelerateLeft();
                            pl2.accelerateLeft();
                            break;
                        }
                           else{
                        pl2.accelerateLeft();
                        break;}
                }
                // 左キーが押されていれば左向きに加速
                
                
            } else if (goRightKey.isPressed()) {
                                switch(pnum){
                    case 0:
                        if(cnum ==2){
                            player.accelerateRight();
                            pl2.accelerateRight();
                            break;
                        }
                           else{
                        player.accelerateRight();
                        break;}
                    case 1:
                        if(cnum ==1){
                            player.accelerateRight();
                            pl2.accelerateRight();
                            break;
                        }
                           else{
                        pl2.accelerateRight();
                        break;}
                }
                // 右キーが押されていれば右向きに加速
                
                
            } else {
                // 何も押されてないときは停止
                player.stop();
                pl2.stop();
            }

            if (jumpKey.isPressed()) {
                // ジャンプする
                switch(pnum){
                    case 0:
                        if(cnum ==2){
                            player.jump();
                            pl2.jump2();
                            break;
                        }
                           else{
                        player.jump();
                        break;}
                    case 1:
                        if(cnum ==1){
                            player.jump2();
                            pl2.jump();
                            break;
                        }
                           else{
                        pl2.jump();
                        break;}
                }
            //    player.jump();
            //    pl2.jump();
            }
            
            if (kirikaeKey.isPressed()) {
                //System.out.println("YES TAKASU CLINIC");
                if(sc.getIre()>0){
                sc.setIre(sc.getIre() - 1);
                }
                
                switch(pnum){
                    case 0:
                        pnum = 1;
                        
                        break;
                    case 1:
                        pnum = 0;
                        break;
                }
            }

            // プレイヤーの状態を更新
            if(pnum==1 && cnum == 1)
                player.update2(pl2);
            else
                player.update();
            
            if(pnum==0 && cnum==2)
                pl2.update2(player);
            else
                pl2.update();
            
            // マップにいるスプライトを取得
            LinkedList sprites = map.getSprites();            
            Iterator iterator = sprites.iterator();
            while (iterator.hasNext()) {
                Sprite sprite = (Sprite)iterator.next();
                
                // スプライトの状態を更新する
                sprite.update();
                
         if (iscol2()) {

                            if ((int)player.getY() < (int)pl2.getY()) {
                      player.humu();
                           
                           cnum = 1;
                        }
                            
                            if((int)pl2.getY() < (int)player.getY()){
                            pl2.humu();
                            cnum = 2;
                            }
                          
                    }else{
                cnum = 0;
             //   System.out.println("fff*");
                }
                
                
                

                // プレイヤーと接触してたら
                if (player.isCollision(sprite)) {
                    if (sprite instanceof Coin) {  // コイン
                        Coin coin = (Coin)sprite;
                        // コインは消える
                        sprites.remove(coin);
                        // ちゃり～ん
                        coin.play();
                        // spritesから削除したので
                        // breakしないとiteratorがおかしくなる
                        break;
                    } else if (sprite instanceof Kuribo) {  // 栗ボー
                        Kuribo kuribo = (Kuribo)sprite;
                        // 上から踏まれてたら
                        if ((int)player.getY() < (int)kuribo.getY()) {
                            // 栗ボーは消える
                            sprites.remove(kuribo);
                            // サウンド
                            kuribo.play();
                            // 踏むとプレイヤーは再ジャンプ
                            player.setForceJump(true);
                            player.jump();
                            break;
                        } else {
                            // ゲームオーバー
                            gameOver();
                        }
                    } else if (sprite instanceof Accelerator) {  // 加速アイテム
                        // アイテムは消える
                        sprites.remove(sprite);
                        Accelerator accelerator = (Accelerator)sprite;
                        // サウンド
                        accelerator.play();
                        // アイテムをその場で使う
                        accelerator.use(player);
                        break;
                    }
                }
            }
            
            // 再描画
            repaint();

            // 休止
            try {
                Thread.sleep(20);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 描画処理
     * 
     * @param 描画オブジェクト
     */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        // 背景を黒で塗りつぶす
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());

        // X方向のオフセットを計算
        int offsetX = MainPanel.WIDTH / 2 - (int)player.getX();
        int offsetX2 = MainPanel.WIDTH / 2 - (int)pl2.getX();
        // マップの端ではスクロールしないようにする
        offsetX = Math.min(offsetX, 0);
        offsetX = Math.max(offsetX, MainPanel.WIDTH - map.getWidth());
        offsetX2 = Math.min(offsetX2, 0);
        offsetX2 = Math.max(offsetX2, MainPanel.WIDTH - map.getWidth());
        // Y方向のオフセットを計算
        int offsetY = MainPanel.HEIGHT / 2 - (int)player.getY();
        int offsetY2 = MainPanel.HEIGHT / 2 - (int)pl2.getY();
        // マップの端ではスクロールしないようにする
        offsetY = Math.min(offsetY, 0);
        offsetY = Math.max(offsetY, MainPanel.HEIGHT - map.getHeight());
                offsetY2 = Math.min(offsetY2, 0);
        offsetY2 = Math.max(offsetY2, MainPanel.HEIGHT - map.getHeight());

        // マップを描画
        map.draw(g, offsetX, offsetY);

        // プレイヤーを描画
        player.draw(g, offsetX, offsetY);
        
        pl2.draw(g, offsetX, offsetY);
        
        // スプライトを描画
        // マップにいるスプライトを取得
        LinkedList sprites = map.getSprites();            
        Iterator iterator = sprites.iterator();
        while (iterator.hasNext()) {
            Sprite sprite = (Sprite)iterator.next();
            sprite.draw(g, offsetX, offsetY);
        }
        
        sc.draw(g, sc.getIre());
        
    }

    /**
     * キーが押されたらキーの状態を「押された」に変える
     * 
     * @param e キーイベント
     */
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT) {
            goLeftKey.press();
        }
        if (key == KeyEvent.VK_RIGHT) {
            goRightKey.press();
        }
        if (key == KeyEvent.VK_UP) {
            jumpKey.press();
        }
        if (key == KeyEvent.VK_Z) {
            kirikaeKey.press();
        }
    }

    /**
     * キーが離されたらキーの状態を「離された」に変える
     * 
     * @param e キーイベント
     */
    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT) {
            goLeftKey.release();
        }
        if (key == KeyEvent.VK_RIGHT) {
            goRightKey.release();
        }
        if (key == KeyEvent.VK_UP) {
            jumpKey.release();
        }
         if (key == KeyEvent.VK_Z) {
            kirikaeKey.release();
        }
    }

    public void keyTyped(KeyEvent e) {
    }
}
