package jtp.c.dendai.ac.jp.action_sample;

/**
 * Created by 14ec0 on 2017/07/03.
 */

public class Rakka {

    private int kazu = 3;

    public void rakka() {
        kazu -= 1;

    }

    public int getrakka() {
        return kazu;
    }


    public void resetr() {
        kazu = 3;

    }

}
